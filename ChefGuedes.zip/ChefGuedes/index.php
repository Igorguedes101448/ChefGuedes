<!DOCTYPE html>
<html lang="pt-BR">
<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ChefGuedes - Início</title>
        <link rel="stylesheet" href="css/style.css">
        <style>
            /* small overrides for index layout */
            body{background:linear-gradient(135deg,#80d0c7 0%,#13547a 100%);}
            .app-shell{min-height:100vh;display:flex;flex-direction:column}
            header.app-header{display:flex;align-items:center;justify-content:space-between;padding:18px 28px;background:linear-gradient(180deg,rgba(255,255,255,0.06),rgba(255,255,255,0));}
            header .brand{color:#fff;font-weight:800;font-size:20px}
            .hero{padding:40px 28px;color:#fff}
            .hero h2{font-size:32px;margin-bottom:8px}
            .hero p{opacity:0.9}
            .content{padding:28px}
            .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:18px}
            .card-recipe{background:#fff;border-radius:10px;padding:12px;box-shadow:0 10px 30px rgba(11,22,30,0.12)}
            .logout-btn{background:linear-gradient(90deg,#0abf9b,#12a37a);color:#fff;padding:8px 12px;border-radius:8px;border:none;cursor:pointer}
        </style>
</head>
<body>
<?php
session_start();
$username = $_SESSION['username'] ?? null;
?>
<div class="app-shell">
    <header class="app-header">
        <div class="brand">ChefGuedes</div>
        <div>
            <?php if($username): ?>
                <span style="color:#fff;margin-right:12px">Olá, <?=htmlspecialchars($username)?></span>
                <form method="post" action="logout.php" style="display:inline">
                    <button class="logout-btn" type="submit">Logout</button>
                </form>
            <?php else: ?>
                <a href="login.php" class="logout-btn" style="text-decoration:none">Login</a>
            <?php endif; ?>
        </div>
    </header>

    <section class="hero">
        <h2>Bem-vindo ao ChefGuedes</h2>
        <p>Explore receitas, compartilhe suas criações e descubra os favoritos da comunidade.</p>
    </section>

    <main class="content">
        <h3 style="color:#fff;margin-bottom:12px">Receitas em destaque</h3>
        <div class="grid">
            <div class="card-recipe"> <h4>Salada de Quinoa</h4><p>Vegetariana — fácil e rápida</p> </div>
            <div class="card-recipe"> <h4>Frango Assado</h4><p>Clássico assado com ervas</p> </div>
            <div class="card-recipe"> <h4>Bolo de Chocolate</h4><p>Doce perfeito para sobremesa</p> </div>
        </div>
    </main>
</div>

</body>
</html>